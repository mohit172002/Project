#include <iostream>
#include <vector>

int main() {
    std::string input;
    std::cout << "Enter the queue as comma-separated numbers: ";
    std::cin >> input;

    std::vector<int> queue;
    size_t pos = 0;
    int turns = 0;

    while ((pos = input.find(",")) != std::string::npos) {
        int num = std::stoi(input.substr(0, pos));
        if (num - queue.size() > 2) {
            turns = -1;
            break;
        }
        for (int i = std::max(0, num - 2); i < queue.size(); ++i) {
            if (queue[i] > num) {
                ++turns;
            }
        }
        queue.push_back(num);
        input.erase(0, pos + 1);
    }

    if (turns == -1) {
        std::cout << "NO-TICKET" << std::endl;
    } else {
        std::cout << turns << std::endl;
    }

    return 0;
}